#! /bin/sh
# artifact com.attivio.3rdparty:full
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/4.0.10/full-4.0.10.pom -Dfile=./com/attivio/3rdparty/full/4.0.10/full-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.3rdparty.full:boilerpipe-1.2.0-aie
if [ -f "${ATTIVIO_HOME}/lib/boilerpipe-1.2.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/boilerpipe-1.2.0-aie/4.0.10/boilerpipe-1.2.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/boilerpipe-1.2.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:commons-httpclient-3.1-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-httpclient-3.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/commons-httpclient-3.1-aie/4.0.10/commons-httpclient-3.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/commons-httpclient-3.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:datasift-java-2.2.2-aie
if [ -f "${ATTIVIO_HOME}/lib/datasift-java-2.2.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/datasift-java-2.2.2-aie/4.0.10/datasift-java-2.2.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/datasift-java-2.2.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-commons-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-commons-2.0.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-commons-2.0.2-aie/4.0.10/heritrix-commons-2.0.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-commons-2.0.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-commons-util-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-commons-util-2.0.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-commons-util-2.0.2-aie/4.0.10/heritrix-commons-util-2.0.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-commons-util-2.0.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-engine-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-engine-2.0.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-engine-2.0.2-aie/4.0.10/heritrix-engine-2.0.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-engine-2.0.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-modules-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-modules-2.0.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-modules-2.0.2-aie/4.0.10/heritrix-modules-2.0.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-modules-2.0.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-webui-2.0.1-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-webui-2.0.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-webui-2.0.1-aie/4.0.10/heritrix-webui-2.0.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-webui-2.0.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:hsqldb-2.3-aie
if [ -f "${ATTIVIO_HOME}/lib/hsqldb-2.3-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/hsqldb-2.3-aie/4.0.10/hsqldb-2.3-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/hsqldb-2.3-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:htmlunit-2.12-aie
if [ -f "${ATTIVIO_HOME}/lib/htmlunit-2.12-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/htmlunit-2.12-aie/4.0.10/htmlunit-2.12-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/htmlunit-2.12-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:json-lib-2013-04-13-aie
if [ -f "${ATTIVIO_HOME}/lib/json-lib-2013-04-13-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/json-lib-2013-04-13-aie/4.0.10/json-lib-2013-04-13-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/json-lib-2013-04-13-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:mule-1.4.4-aie
if [ -f "${ATTIVIO_HOME}/lib/mule-1.4.4-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/mule-1.4.4-aie/4.0.10/mule-1.4.4-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/mule-1.4.4-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.full:zookeeper-3.4.2-aie
if [ -f "${ATTIVIO_HOME}/lib/zookeeper-3.4.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/zookeeper-3.4.2-aie/4.0.10/zookeeper-3.4.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/zookeeper-3.4.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty:partial
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/4.0.10/partial-4.0.10.pom -Dfile=./com/attivio/3rdparty/partial/4.0.10/partial-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.3rdparty.partial:activemq-core-5.7.0-aie
if [ -f "${ATTIVIO_HOME}/lib/activemq-core-5.7.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/activemq-core-5.7.0-aie/4.0.10/activemq-core-5.7.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/activemq-core-5.7.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:aperture-core-1.5.0-aie
if [ -f "${ATTIVIO_HOME}/lib/aperture-core-1.5.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/aperture-core-1.5.0-aie/4.0.10/aperture-core-1.5.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aperture-core-1.5.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:astyanax-recipes-1.56.44-aie
if [ -f "${ATTIVIO_HOME}/lib/astyanax-recipes-1.56.44-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/astyanax-recipes-1.56.44-aie/4.0.10/astyanax-recipes-1.56.44-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/astyanax-recipes-1.56.44-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:clapper-javautil-3.1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/clapper-javautil-3.1.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/clapper-javautil-3.1.1-aie/4.0.10/clapper-javautil-3.1.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/clapper-javautil-3.1.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-cli-1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-cli-1.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-cli-1.1-aie/4.0.10/commons-cli-1.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/commons-cli-1.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-pool-1.3-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-pool-1.3-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-pool-1.3-aie/4.0.10/commons-pool-1.3-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/commons-pool-1.3-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-vfs2-2.0-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-vfs2-2.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-vfs2-2.0-aie/4.0.10/commons-vfs2-2.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/commons-vfs2-2.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:dom4j-1.6.1-aie
if [ -f "${ATTIVIO_HOME}/lib/dom4j-1.6.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/dom4j-1.6.1-aie/4.0.10/dom4j-1.6.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/dom4j-1.6.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:domingo-1.5.1-aie
if [ -f "${ATTIVIO_HOME}/lib/domingo-1.5.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/domingo-1.5.1-aie/4.0.10/domingo-1.5.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/domingo-1.5.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:jaxen-1.1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/jaxen-1.1.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jaxen-1.1.1-aie/4.0.10/jaxen-1.1.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/jaxen-1.1.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:jpod-5.2-aie
if [ -f "${ATTIVIO_HOME}/lib/jpod-5.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jpod-5.2-aie/4.0.10/jpod-5.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/jpod-5.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:jtidy-r938-aie
if [ -f "${ATTIVIO_HOME}/lib/jtidy-r938-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jtidy-r938-aie/4.0.10/jtidy-r938-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/jtidy-r938-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:language-identifier-1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/language-identifier-1.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/language-identifier-1.1-aie/4.0.10/language-identifier-1.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/language-identifier-1.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:log4j-1.2.15-aie
if [ -f "${ATTIVIO_HOME}/lib/log4j-1.2.15-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/log4j-1.2.15-aie/4.0.10/log4j-1.2.15-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/log4j-1.2.15-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:lucene-core-4.3.0-aie
if [ -f "${ATTIVIO_HOME}/lib/lucene-core-4.3.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/lucene-core-4.3.0-aie/4.0.10/lucene-core-4.3.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/lucene-core-4.3.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:mx4j-tools-3.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/mx4j-tools-3.0.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/mx4j-tools-3.0.2-aie/4.0.10/mx4j-tools-3.0.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/mx4j-tools-3.0.2-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:nekohtml-1.9.18-aie
if [ -f "${ATTIVIO_HOME}/lib/nekohtml-1.9.18-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/nekohtml-1.9.18-aie/4.0.10/nekohtml-1.9.18-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/nekohtml-1.9.18-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:poi-3.2-NIObackport-20110105-aie
if [ -f "${ATTIVIO_HOME}/lib/poi-3.2-NIObackport-20110105-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/poi-3.2-NIObackport-20110105-aie/4.0.10/poi-3.2-NIObackport-20110105-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/poi-3.2-NIObackport-20110105-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:poi-scratchpad-3.2-NIObackport-20110105-aie
if [ -f "${ATTIVIO_HOME}/lib/poi-scratchpad-3.2-NIObackport-20110105-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/poi-scratchpad-3.2-NIObackport-20110105-aie/4.0.10/poi-scratchpad-3.2-NIObackport-20110105-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/poi-scratchpad-3.2-NIObackport-20110105-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:slf4j-api-1.6.1-aie
if [ -f "${ATTIVIO_HOME}/lib/slf4j-api-1.6.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/slf4j-api-1.6.1-aie/4.0.10/slf4j-api-1.6.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/slf4j-api-1.6.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:spring-security-core-3.1.3.RELEASE-aie
if [ -f "${ATTIVIO_HOME}/lib/spring-security-core-3.1.3.RELEASE-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/spring-security-core-3.1.3.RELEASE-aie/4.0.10/spring-security-core-3.1.3.RELEASE-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/spring-security-core-3.1.3.RELEASE-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:tm-extractors-1.0-aie
if [ -f "${ATTIVIO_HOME}/lib/tm-extractors-1.0-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/tm-extractors-1.0-aie/4.0.10/tm-extractors-1.0-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/tm-extractors-1.0-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:unrar-alpha-0.1-aie
if [ -f "${ATTIVIO_HOME}/lib/unrar-alpha-0.1-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/unrar-alpha-0.1-aie/4.0.10/unrar-alpha-0.1-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/unrar-alpha-0.1-aie-4.0.10.jar"; fi
# artifact com.attivio.3rdparty.partial:xstream-1.4.2-aie
if [ -f "${ATTIVIO_HOME}/lib/xstream-1.4.2-aie-4.0.10.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/xstream-1.4.2-aie/4.0.10/xstream-1.4.2-aie-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/xstream-1.4.2-aie-4.0.10.jar"; fi
# artifact com.attivio.platform:3rdparty
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/3rdparty/4.0.10/3rdparty-4.0.10.pom -Dfile=./com/attivio/platform/3rdparty/4.0.10/3rdparty-4.0.10.pom -Dpackaging=pom
# artifact com.attivio:platform
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/4.0.10/platform-4.0.10.pom -Dfile=./com/attivio/platform/4.0.10/platform-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform:app
if [ -f "${ATTIVIO_HOME}/lib/aie-core-app.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/app/4.0.10/app-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-app.jar" -Dfiles=${ATTIVIO_HOME}/sdk/lib-test/aie-core-app-tests.jar -Dclassifiers=tests -Dtypes=jar; fi
# artifact com.attivio.platform:core
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/4.0.10/core-4.0.10.pom -Dfile=./com/attivio/platform/core/4.0.10/core-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.core:api
if [ -f "${ATTIVIO_HOME}/lib/aie-core-api.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/api/4.0.10/api-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-api.jar"; fi
# artifact com.attivio.platform.core:kernel
if [ -f "${ATTIVIO_HOME}/lib/aie-core-kernel.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/kernel/4.0.10/kernel-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-kernel.jar"; fi
# artifact com.attivio.platform.core:model
if [ -f "${ATTIVIO_HOME}/lib/aie-core-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/model/4.0.10/model-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-model.jar"; fi
# artifact com.attivio.platform.languagemodels:lm
if [ -f "${ATTIVIO_HOME}/lib/lm-0.1-en.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/languagemodels/lm/0.1/lm-0.1.pom -Dfile="${ATTIVIO_HOME}/lib/lm-0.1-en.jar" -Dclassifier=en; fi
# artifact com.attivio.platform:modules
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/4.0.10/modules-4.0.10.pom -Dfile=./com/attivio/platform/modules/4.0.10/modules-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.modules:advancedtextextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-advancedtextextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/advancedtextextraction/4.0.10/advancedtextextraction-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-advancedtextextraction.jar"; fi
# artifact com.attivio.platform.modules.advancedtextextraction:advancedtextextraction-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/advancedtextextraction/advancedtextextraction-parent/4.0.10/advancedtextextraction-parent-4.0.10.pom -Dfile=./com/attivio/platform/modules/advancedtextextraction/advancedtextextraction-parent/4.0.10/advancedtextextraction-parent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.modules.alerts:parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/alerts/parent/4.0.10/parent-4.0.10.pom -Dfile=./com/attivio/platform/modules/alerts/parent/4.0.10/parent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.modules.alerts:sdk
if [ -f "${ATTIVIO_HOME}/lib/aie-sdk-module-alerts.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/alerts/sdk/4.0.10/sdk-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-sdk-module-alerts.jar"; fi
# artifact com.attivio.platform.modules:autocomplete
if [ -f "${ATTIVIO_HOME}/lib/aie-module-autocomplete.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/autocomplete/4.0.10/autocomplete-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-autocomplete.jar"; fi
# artifact com.attivio.platform.modules:basistech
if [ -f "${ATTIVIO_HOME}/lib/aie-module-basistech.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/basistech/4.0.10/basistech-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-basistech.jar"; fi
# artifact com.attivio.platform.modules:classifier
if [ -f "${ATTIVIO_HOME}/lib/aie-module-classifier.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/classifier/4.0.10/classifier-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-classifier.jar"; fi
# artifact com.attivio.platform.modules:clib
if [ -f "${ATTIVIO_HOME}/lib/aie-module-clib.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clib/4.0.10/clib-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-clib.jar"; fi
# artifact com.attivio.platform.modules.clib:clib-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clib/clib-parent/4.0.10/clib-parent-4.0.10.pom -Dfile=./com/attivio/platform/modules/clib/clib-parent/4.0.10/clib-parent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.modules:clustering
if [ -f "${ATTIVIO_HOME}/lib/aie-module-clustering.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clustering/4.0.10/clustering-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-clustering.jar"; fi
# artifact com.attivio.platform.modules:connectors-runtime
if [ -f "${ATTIVIO_HOME}/lib/aie-module-connectors-runtime.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/connectors-runtime/4.0.10/connectors-runtime-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-connectors-runtime.jar"; fi
# artifact com.attivio.platform.modules:crawlerstore
if [ -f "${ATTIVIO_HOME}/lib/aie-module-crawlerstore.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/crawlerstore/4.0.10/crawlerstore-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-crawlerstore.jar"; fi
# artifact com.attivio.platform.modules:datasift
if [ -f "${ATTIVIO_HOME}/lib/aie-module-datasift.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/datasift/4.0.10/datasift-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-datasift.jar"; fi
# artifact com.attivio.platform.modules:dbconnector
if [ -f "${ATTIVIO_HOME}/lib/aie-module-dbconnector.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/dbconnector/4.0.10/dbconnector-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-dbconnector.jar"; fi
# artifact com.attivio.platform.modules:documentstore
if [ -f "${ATTIVIO_HOME}/lib/aie-module-documentstore.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/documentstore/4.0.10/documentstore-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-documentstore.jar"; fi
# artifact com.attivio.platform.modules:entityextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-entityextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/entityextraction/4.0.10/entityextraction-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-entityextraction.jar"; fi
# artifact com.attivio.platform.modules:entitysentiment
if [ -f "${ATTIVIO_HOME}/lib/aie-module-entitysentiment.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/entitysentiment/4.0.10/entitysentiment-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-entitysentiment.jar"; fi
# artifact com.attivio.platform.modules:gwt-commons
if [ -f "${ATTIVIO_HOME}/lib/aie-module-gwt-commons.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/gwt-commons/4.0.10/gwt-commons-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-gwt-commons.jar"; fi
# artifact com.attivio.platform.modules:jdbcutils
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jdbcutils.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jdbcutils/4.0.10/jdbcutils-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jdbcutils.jar"; fi
# artifact com.attivio.platform.modules:jms
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jms.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jms/4.0.10/jms-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jms.jar"; fi
# artifact com.attivio.platform.modules:keyphrases
if [ -f "${ATTIVIO_HOME}/lib/aie-module-keyphrases.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/keyphrases/4.0.10/keyphrases-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-keyphrases.jar"; fi
# artifact com.attivio.platform.modules:languagemodel
if [ -f "${ATTIVIO_HOME}/lib/aie-module-languagemodel.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/languagemodel/4.0.10/languagemodel-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-languagemodel.jar"; fi
# artifact com.attivio.platform.modules:memory
if [ -f "${ATTIVIO_HOME}/lib/aie-module-memory.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/memory/4.0.10/memory-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-memory.jar"; fi
# artifact com.attivio.platform.modules:morelikethis
if [ -f "${ATTIVIO_HOME}/lib/aie-module-morelikethis.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/morelikethis/4.0.10/morelikethis-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-morelikethis.jar"; fi
# artifact com.attivio.platform.modules:ontology
if [ -f "${ATTIVIO_HOME}/lib/aie-module-ontology.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/ontology/4.0.10/ontology-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-ontology.jar"; fi
# artifact com.attivio.platform.modules:predictive
if [ -f "${ATTIVIO_HOME}/lib/aie-module-predictive.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/predictive/4.0.10/predictive-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-predictive.jar"; fi
# artifact com.attivio.platform.modules:profiler
if [ -f "${ATTIVIO_HOME}/lib/aie-module-profiler.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/profiler/4.0.10/profiler-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-profiler.jar"; fi
# artifact com.attivio.platform.modules:sail
if [ -f "${ATTIVIO_HOME}/lib/aie-module-sail.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/sail/4.0.10/sail-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-sail.jar"; fi
# artifact com.attivio.platform.modules.scheduler:parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/scheduler/parent/4.0.10/parent-4.0.10.pom -Dfile=./com/attivio/platform/modules/scheduler/parent/4.0.10/parent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.modules.scheduler:sdk
if [ -f "${ATTIVIO_HOME}/lib/aie-sdk-module-scheduler.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/scheduler/sdk/4.0.10/sdk-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-sdk-module-scheduler.jar"; fi
# artifact com.attivio.platform.modules.scheduler:server
if [ -f "${ATTIVIO_HOME}/lib/aie-module-scheduler.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/scheduler/server/4.0.10/server-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-scheduler.jar"; fi
# artifact com.attivio.platform.modules:security
if [ -f "${ATTIVIO_HOME}/lib/aie-module-security.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/security/4.0.10/security-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-security.jar"; fi
# artifact com.attivio.platform.modules:security-ad
if [ -f "${ATTIVIO_HOME}/lib/aie-module-security-ad.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/security-ad/4.0.10/security-ad-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-security-ad.jar"; fi
# artifact com.attivio.platform.modules:sentiment
if [ -f "${ATTIVIO_HOME}/lib/aie-module-sentiment.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/sentiment/4.0.10/sentiment-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-sentiment.jar"; fi
# artifact com.attivio.platform.modules:siteharvester
if [ -f "${ATTIVIO_HOME}/lib/aie-module-siteharvester.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/siteharvester/4.0.10/siteharvester-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-siteharvester.jar"; fi
# artifact com.attivio.platform.modules:sqlsdk
if [ -f "${ATTIVIO_HOME}/lib/aie-module-sqlsdk.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/sqlsdk/4.0.10/sqlsdk-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-sqlsdk.jar"; fi
# artifact com.attivio.platform.modules:textextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-textextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/textextraction/4.0.10/textextraction-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-textextraction.jar"; fi
# artifact com.attivio.platform.modules:webservice
if [ -f "${ATTIVIO_HOME}/lib/aie-module-webservice.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/webservice/4.0.10/webservice-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-webservice.jar"; fi
# artifact com.attivio.platform.modules:workflows
if [ -f "${ATTIVIO_HOME}/lib/aie-module-workflows.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflows/4.0.10/workflows-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-workflows.jar"; fi
# artifact com.attivio.platform.modules:workflowvisualizer
if [ -f "${ATTIVIO_HOME}/lib/aie-module-workflowvisualizer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflowvisualizer/4.0.10/workflowvisualizer-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-workflowvisualizer.jar"; fi
# artifact com.attivio.platform.modules.workflowvisualizer:workflowvisualizer-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflowvisualizer/workflowvisualizer-parent/4.0.10/workflowvisualizer-parent-4.0.10.pom -Dfile=./com/attivio/platform/modules/workflowvisualizer/workflowvisualizer-parent/4.0.10/workflowvisualizer-parent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform:platform
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/4.0.10/platform-4.0.10.pom -Dfile=./com/attivio/platform/platform/4.0.10/platform-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.platform:agent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/agent/4.0.10/agent-4.0.10.pom -Dfile=./com/attivio/platform/platform/agent/4.0.10/agent-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.agent:client
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-agent-client.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/agent/client/4.0.10/client-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-agent-client.jar"; fi
# artifact com.attivio.platform.platform.agent:model
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-agent-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/agent/model/4.0.10/model-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-agent-model.jar"; fi
# artifact com.attivio.platform.platform.agent:server
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-agent-server.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/agent/server/4.0.10/server-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-agent-server.jar"; fi
# artifact com.attivio.platform.platform:base
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/4.0.10/base-4.0.10.pom -Dfile=./com/attivio/platform/platform/base/4.0.10/base-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.base:connector
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-connector.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/connector/4.0.10/connector-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-connector.jar"; fi
# artifact com.attivio.platform.platform.base:tokenizer
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-tokenizer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/tokenizer/4.0.10/tokenizer-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-tokenizer.jar"; fi
# artifact com.attivio.platform.platform.base:transformer
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-transformer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/transformer/4.0.10/transformer-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-transformer.jar"; fi
# artifact com.attivio.platform.platform:esb
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/4.0.10/esb-4.0.10.pom -Dfile=./com/attivio/platform/platform/esb/4.0.10/esb-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.esb:api
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-api.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/api/4.0.10/api-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-api.jar"; fi
# artifact com.attivio.platform.platform.esb:exposedapi
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-exposedapi.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/exposedapi/4.0.10/exposedapi-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-exposedapi.jar"; fi
# artifact com.attivio.platform.platform.esb:launcher
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-launcher.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/launcher/4.0.10/launcher-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-launcher.jar"; fi
# artifact com.attivio.platform.platform.esb:model
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/model/4.0.10/model-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-model.jar"; fi
# artifact com.attivio.platform.platform.esb:mule
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-mule.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/mule/4.0.10/mule-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-mule.jar"; fi
# artifact com.attivio.platform.platform.esb:zoo
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-zoo.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/zoo/4.0.10/zoo-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-zoo.jar"; fi
# artifact com.attivio.platform.platform:perfmon
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/4.0.10/perfmon-4.0.10.pom -Dfile=./com/attivio/platform/platform/perfmon/4.0.10/perfmon-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.perfmon:client
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-client.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/client/4.0.10/client-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-client.jar"; fi
# artifact com.attivio.platform.platform.perfmon:model
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/model/4.0.10/model-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-model.jar"; fi
# artifact com.attivio.platform.platform.perfmon:server
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-server.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/server/4.0.10/server-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-server.jar"; fi
# artifact com.attivio.platform.platform:sigar
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-sigar.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/sigar/4.0.10/sigar-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-sigar.jar"; fi
# artifact com.attivio.platform.platform:springutil
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-springutil.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/springutil/4.0.10/springutil-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-springutil.jar"; fi
# artifact com.attivio.platform.platform:store
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-store.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/store/4.0.10/store-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-store.jar"; fi
# artifact com.attivio.platform.platform:util
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-util.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/util/4.0.10/util-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-util.jar"; fi
# artifact com.attivio.platform:sdk
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/sdk/4.0.10/sdk-4.0.10.pom -Dfile=./com/attivio/platform/sdk/4.0.10/sdk-4.0.10.pom -Dpackaging=pom
# artifact com.attivio.platform.sdk:client
if [ -f "${ATTIVIO_HOME}/lib/aie-sdk-client.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/sdk/client/4.0.10/client-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-sdk-client.jar"; fi
# artifact com.attivio.platform.sdk:model
if [ -f "${ATTIVIO_HOME}/lib/aie-sdk-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/sdk/model/4.0.10/model-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-sdk-model.jar"; fi
# artifact com.attivio.platform.sdk:server
if [ -f "${ATTIVIO_HOME}/lib/aie-sdk-server.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/sdk/server/4.0.10/server-4.0.10.pom -Dfile="${ATTIVIO_HOME}/lib/aie-sdk-server.jar"; fi
# artifact com.ibm.icu:icu4j
if [ -f "${ATTIVIO_HOME}/lib/icu4j-3.8.1.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/ibm/icu/icu4j/3.8.1/icu4j-3.8.1.pom -Dfile="${ATTIVIO_HOME}/lib/icu4j-3.8.1.jar"; fi
# artifact de.intrasys.cwt:iscwt
if [ -f "${ATTIVIO_HOME}/lib/iscwt-5.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./de/intrasys/cwt/iscwt/5.2/iscwt-5.2.pom -Dfile="${ATTIVIO_HOME}/lib/iscwt-5.2.jar"; fi
# artifact de.intrasys.tools:isrt
if [ -f "${ATTIVIO_HOME}/lib/isrt-4.7.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./de/intrasys/tools/isrt/4.7/isrt-4.7.pom -Dfile="${ATTIVIO_HOME}/lib/isrt-4.7.jar"; fi
# artifact javax.management:jmxremote_optional
if [ -f "${ATTIVIO_HOME}/lib/jmxremote_optional-1.0.1_04.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./javax/management/jmxremote_optional/1.0.1_04/jmxremote_optional-1.0.1_04.pom -Dfile="${ATTIVIO_HOME}/lib/jmxremote_optional-1.0.1_04.jar"; fi
# artifact opencsv:opencsv
if [ -f "${ATTIVIO_HOME}/lib/opencsv-1.8.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./opencsv/opencsv/1.8/opencsv-1.8.pom -Dfile="${ATTIVIO_HOME}/lib/opencsv-1.8.jar"; fi
# artifact org.apache.poi:poi-contrib
if [ -f "${ATTIVIO_HOME}/lib/poi-contrib-3.2-NIObackport-20110105.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/apache/poi/poi-contrib/3.2-NIObackport-20110105/poi-contrib-3.2-NIObackport-20110105.pom -Dfile="${ATTIVIO_HOME}/lib/poi-contrib-3.2-NIObackport-20110105.jar"; fi
# artifact org.hyperic.sigar:sigar
if [ -f "${ATTIVIO_HOME}/lib/sigar-1.6.4-attiviopatch2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/hyperic/sigar/sigar/1.6.4-attiviopatch2/sigar-1.6.4-attiviopatch2.pom -Dfile="${ATTIVIO_HOME}/lib/sigar-1.6.4-attiviopatch2.jar"; fi
# artifact org.jpedal:jbig2
if [ -f "${ATTIVIO_HOME}/lib/jbig2-1.5.0_12-b04.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/jpedal/jbig2/1.5.0_12-b04/jbig2-1.5.0_12-b04.pom -Dfile="${ATTIVIO_HOME}/lib/jbig2-1.5.0_12-b04.jar"; fi
# artifact rtf2fo:rtf2fo
if [ -f "${ATTIVIO_HOME}/lib/rtf2fo-3.4.4d.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./rtf2fo/rtf2fo/3.4.4d/rtf2fo-3.4.4d.pom -Dfile="${ATTIVIO_HOME}/lib/rtf2fo-3.4.4d.jar"; fi
# artifact trove:trove
if [ -f "${ATTIVIO_HOME}/lib/trove-2.0.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./trove/trove/2.0.2/trove-2.0.2.pom -Dfile="${ATTIVIO_HOME}/lib/trove-2.0.2.jar"; fi
# artifact velocity:velocity
if [ -f "${ATTIVIO_HOME}/lib/velocity-1.6.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./velocity/velocity/1.6.2/velocity-1.6.2.pom -Dfile="${ATTIVIO_HOME}/lib/velocity-1.6.2.jar"; fi
# artifact velocity:velocity-tools
if [ -f "${ATTIVIO_HOME}/lib/velocity-tools-1.4.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./velocity/velocity-tools/1.4/velocity-tools-1.4.pom -Dfile="${ATTIVIO_HOME}/lib/velocity-tools-1.4.jar"; fi
