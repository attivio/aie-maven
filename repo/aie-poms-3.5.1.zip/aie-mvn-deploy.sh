#! /bin/sh
# artifact com.attivio.3rdparty:full
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/3.5.1/full-3.5.1.pom -Dfile=./com/attivio/3rdparty/full/3.5.1/full-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.3rdparty.full:heritrix-commons-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-commons-2.0.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-commons-2.0.2-aie/3.5.1/heritrix-commons-2.0.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-commons-2.0.2-aie.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-commons-util-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-commons-util-2.0.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-commons-util-2.0.2-aie/3.5.1/heritrix-commons-util-2.0.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-commons-util-2.0.2-aie.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-engine-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-engine-2.0.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-engine-2.0.2-aie/3.5.1/heritrix-engine-2.0.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-engine-2.0.2-aie.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-modules-2.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-modules-2.0.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-modules-2.0.2-aie/3.5.1/heritrix-modules-2.0.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-modules-2.0.2-aie.jar"; fi
# artifact com.attivio.3rdparty.full:heritrix-webui-2.0.1-aie
if [ -f "${ATTIVIO_HOME}/lib/heritrix-webui-2.0.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/heritrix-webui-2.0.1-aie/3.5.1/heritrix-webui-2.0.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/heritrix-webui-2.0.1-aie.jar"; fi
# artifact com.attivio.3rdparty.full:jetty-client-6.1.26-aie
if [ -f "${ATTIVIO_HOME}/lib/jetty-client-6.1.26-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/jetty-client-6.1.26-aie/3.5.1/jetty-client-6.1.26-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/jetty-client-6.1.26-aie.jar"; fi
# artifact com.attivio.3rdparty.full:lucene-analyzers-3.4.0-aie
if [ -f "${ATTIVIO_HOME}/lib/lucene-analyzers-3.4.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/lucene-analyzers-3.4.0-aie/3.5.1/lucene-analyzers-3.4.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/lucene-analyzers-3.4.0-aie.jar"; fi
# artifact com.attivio.3rdparty.full:lucene-core-3.4.0-aie
if [ -f "${ATTIVIO_HOME}/lib/lucene-core-3.4.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/lucene-core-3.4.0-aie/3.5.1/lucene-core-3.4.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/lucene-core-3.4.0-aie.jar"; fi
# artifact com.attivio.3rdparty.full:mule-1.4.4-aie
if [ -f "${ATTIVIO_HOME}/lib/mule-1.4.4-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/mule-1.4.4-aie/3.5.1/mule-1.4.4-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/mule-1.4.4-aie.jar"; fi
# artifact com.attivio.3rdparty.full:zookeeper-3.4.2-aie
if [ -f "${ATTIVIO_HOME}/lib/zookeeper-3.4.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/full/zookeeper-3.4.2-aie/3.5.1/zookeeper-3.4.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/zookeeper-3.4.2-aie.jar"; fi
# artifact com.attivio.3rdparty:partial
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/3.5.1/partial-3.5.1.pom -Dfile=./com/attivio/3rdparty/partial/3.5.1/partial-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.3rdparty.partial:activemq-core-5.7.0-aie
if [ -f "${ATTIVIO_HOME}/lib/activemq-core-5.7.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/activemq-core-5.7.0-aie/3.5.1/activemq-core-5.7.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/activemq-core-5.7.0-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:aperture-core-1.5.0-aie
if [ -f "${ATTIVIO_HOME}/lib/aperture-core-1.5.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/aperture-core-1.5.0-aie/3.5.1/aperture-core-1.5.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aperture-core-1.5.0-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:clapper-javautil-3.1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/clapper-javautil-3.1.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/clapper-javautil-3.1.1-aie/3.5.1/clapper-javautil-3.1.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/clapper-javautil-3.1.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-cli-1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-cli-1.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-cli-1.1-aie/3.5.1/commons-cli-1.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/commons-cli-1.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-httpclient-3.1-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-httpclient-3.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-httpclient-3.1-aie/3.5.1/commons-httpclient-3.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/commons-httpclient-3.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-pool-1.3-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-pool-1.3-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-pool-1.3-aie/3.5.1/commons-pool-1.3-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/commons-pool-1.3-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:commons-vfs2-2.0-aie
if [ -f "${ATTIVIO_HOME}/lib/commons-vfs2-2.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/commons-vfs2-2.0-aie/3.5.1/commons-vfs2-2.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/commons-vfs2-2.0-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:dom4j-1.6.1-aie
if [ -f "${ATTIVIO_HOME}/lib/dom4j-1.6.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/dom4j-1.6.1-aie/3.5.1/dom4j-1.6.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/dom4j-1.6.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:domingo-1.5.1-aie
if [ -f "${ATTIVIO_HOME}/lib/domingo-1.5.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/domingo-1.5.1-aie/3.5.1/domingo-1.5.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/domingo-1.5.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:jaxen-1.1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/jaxen-1.1.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jaxen-1.1.1-aie/3.5.1/jaxen-1.1.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/jaxen-1.1.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:jetty-6.1.26-aie
if [ -f "${ATTIVIO_HOME}/lib/jetty-6.1.26-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jetty-6.1.26-aie/3.5.1/jetty-6.1.26-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/jetty-6.1.26-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:jpod-5.2-aie
if [ -f "${ATTIVIO_HOME}/lib/jpod-5.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jpod-5.2-aie/3.5.1/jpod-5.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/jpod-5.2-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:jtidy-r938-aie
if [ -f "${ATTIVIO_HOME}/lib/jtidy-r938-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/jtidy-r938-aie/3.5.1/jtidy-r938-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/jtidy-r938-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:language-identifier-1.1-aie
if [ -f "${ATTIVIO_HOME}/lib/language-identifier-1.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/language-identifier-1.1-aie/3.5.1/language-identifier-1.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/language-identifier-1.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:log4j-1.2.15-aie
if [ -f "${ATTIVIO_HOME}/lib/log4j-1.2.15-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/log4j-1.2.15-aie/3.5.1/log4j-1.2.15-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/log4j-1.2.15-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:mx4j-tools-3.0.2-aie
if [ -f "${ATTIVIO_HOME}/lib/mx4j-tools-3.0.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/mx4j-tools-3.0.2-aie/3.5.1/mx4j-tools-3.0.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/mx4j-tools-3.0.2-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:poi-3.2-NIObackport-20110105-aie
if [ -f "${ATTIVIO_HOME}/lib/poi-3.2-NIObackport-20110105-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/poi-3.2-NIObackport-20110105-aie/3.5.1/poi-3.2-NIObackport-20110105-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/poi-3.2-NIObackport-20110105-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:poi-scratchpad-3.2-NIObackport-20110105-aie
if [ -f "${ATTIVIO_HOME}/lib/poi-scratchpad-3.2-NIObackport-20110105-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/poi-scratchpad-3.2-NIObackport-20110105-aie/3.5.1/poi-scratchpad-3.2-NIObackport-20110105-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/poi-scratchpad-3.2-NIObackport-20110105-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:slf4j-api-1.6.1-aie
if [ -f "${ATTIVIO_HOME}/lib/slf4j-api-1.6.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/slf4j-api-1.6.1-aie/3.5.1/slf4j-api-1.6.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/slf4j-api-1.6.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:spring-security-core-3.1.3.RELEASE-aie
if [ -f "${ATTIVIO_HOME}/lib/spring-security-core-3.1.3.RELEASE-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/spring-security-core-3.1.3.RELEASE-aie/3.5.1/spring-security-core-3.1.3.RELEASE-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/spring-security-core-3.1.3.RELEASE-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:tm-extractors-1.0-aie
if [ -f "${ATTIVIO_HOME}/lib/tm-extractors-1.0-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/tm-extractors-1.0-aie/3.5.1/tm-extractors-1.0-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/tm-extractors-1.0-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:unrar-alpha-0.1-aie
if [ -f "${ATTIVIO_HOME}/lib/unrar-alpha-0.1-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/unrar-alpha-0.1-aie/3.5.1/unrar-alpha-0.1-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/unrar-alpha-0.1-aie.jar"; fi
# artifact com.attivio.3rdparty.partial:xstream-1.4.2-aie
if [ -f "${ATTIVIO_HOME}/lib/xstream-1.4.2-aie.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/3rdparty/partial/xstream-1.4.2-aie/3.5.1/xstream-1.4.2-aie-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/xstream-1.4.2-aie.jar"; fi
# artifact com.attivio:platform
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/3.5.1/platform-3.5.1.pom -Dfile=./com/attivio/platform/3.5.1/platform-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform:3rdparty
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/3rdparty/3.5.1/3rdparty-3.5.1.pom -Dfile=./com/attivio/platform/3rdparty/3.5.1/3rdparty-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform:app
if [ -f "${ATTIVIO_HOME}/lib/aie-core-app.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/app/3.5.1/app-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-app.jar" -Dfiles=${ATTIVIO_HOME}/sdk/lib-test/aie-core-app-tests.jar -Dclassifiers=test -Dtypes=jar; fi
# artifact com.attivio.platform:core
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/3.5.1/core-3.5.1.pom -Dfile=./com/attivio/platform/core/3.5.1/core-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.core:api
if [ -f "${ATTIVIO_HOME}/lib/aie-core-api.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/api/3.5.1/api-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-api.jar"; fi
# artifact com.attivio.platform.core:kernel
if [ -f "${ATTIVIO_HOME}/lib/aie-core-kernel.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/kernel/3.5.1/kernel-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-kernel.jar"; fi
# artifact com.attivio.platform.core:model
if [ -f "${ATTIVIO_HOME}/lib/aie-core-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/core/model/3.5.1/model-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-core-model.jar"; fi
# artifact com.attivio.platform.languagemodels:lm
if [ -f "${ATTIVIO_HOME}/lib/lm-0.1-en.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/languagemodels/lm/0.1/lm-0.1.pom -Dfile="${ATTIVIO_HOME}/lib/lm-0.1-en.jar" -Dclassifier=en; fi
# artifact com.attivio.platform:modules
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/3.5.1/modules-3.5.1.pom -Dfile=./com/attivio/platform/modules/3.5.1/modules-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.modules:adminui
if [ -f "${ATTIVIO_HOME}/lib/aie-module-adminui.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/adminui/3.5.1/adminui-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-adminui.jar"; fi
# artifact com.attivio.platform.modules:advancedtextextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-advancedtextextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/advancedtextextraction/3.5.1/advancedtextextraction-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-advancedtextextraction.jar"; fi
# artifact com.attivio.platform.modules.advancedtextextraction:advancedtextextraction-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/advancedtextextraction/advancedtextextraction-parent/3.5.1/advancedtextextraction-parent-3.5.1.pom -Dfile=./com/attivio/platform/modules/advancedtextextraction/advancedtextextraction-parent/3.5.1/advancedtextextraction-parent-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.modules:alerts
if [ -f "${ATTIVIO_HOME}/lib/aie-module-alerts.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/alerts/3.5.1/alerts-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-alerts.jar"; fi
# artifact com.attivio.platform.modules:autocomplete
if [ -f "${ATTIVIO_HOME}/lib/aie-module-autocomplete.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/autocomplete/3.5.1/autocomplete-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-autocomplete.jar"; fi
# artifact com.attivio.platform.modules:basistech
if [ -f "${ATTIVIO_HOME}/lib/aie-module-basistech.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/basistech/3.5.1/basistech-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-basistech.jar"; fi
# artifact com.attivio.platform.modules:classifier
if [ -f "${ATTIVIO_HOME}/lib/aie-module-classifier.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/classifier/3.5.1/classifier-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-classifier.jar"; fi
# artifact com.attivio.platform.modules:clib
if [ -f "${ATTIVIO_HOME}/lib/aie-module-clib.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clib/3.5.1/clib-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-clib.jar"; fi
# artifact com.attivio.platform.modules.clib:clib-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clib/clib-parent/3.5.1/clib-parent-3.5.1.pom -Dfile=./com/attivio/platform/modules/clib/clib-parent/3.5.1/clib-parent-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.modules:clustering
if [ -f "${ATTIVIO_HOME}/lib/aie-module-clustering.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/clustering/3.5.1/clustering-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-clustering.jar"; fi
# artifact com.attivio.platform.modules:connectors-common
if [ -f "${ATTIVIO_HOME}/lib/aie-module-connectors-common.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/connectors-common/3.5.1/connectors-common-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-connectors-common.jar"; fi
# artifact com.attivio.platform.modules:contentspotlight
if [ -f "${ATTIVIO_HOME}/lib/aie-module-contentspotlight.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/contentspotlight/3.5.1/contentspotlight-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-contentspotlight.jar"; fi
# artifact com.attivio.platform.modules:createproject
if [ -f "${ATTIVIO_HOME}/lib/aie-module-createproject.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/createproject/3.5.1/createproject-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-createproject.jar"; fi
# artifact com.attivio.platform.modules:dbconnector
if [ -f "${ATTIVIO_HOME}/lib/aie-module-dbconnector.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/dbconnector/3.5.1/dbconnector-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-dbconnector.jar"; fi
# artifact com.attivio.platform.modules:dictionaryadmin
if [ -f "${ATTIVIO_HOME}/lib/aie-module-dictionaryadmin.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/dictionaryadmin/3.5.1/dictionaryadmin-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-dictionaryadmin.jar"; fi
# artifact com.attivio.platform.modules:entityextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-entityextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/entityextraction/3.5.1/entityextraction-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-entityextraction.jar"; fi
# artifact com.attivio.platform.modules:entitytraining
if [ -f "${ATTIVIO_HOME}/lib/aie-module-entitytraining.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/entitytraining/3.5.1/entitytraining-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-entitytraining.jar"; fi
# artifact com.attivio.platform.modules:exchangeconnector
if [ -f "${ATTIVIO_HOME}/lib/aie-module-exchangeconnector.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/exchangeconnector/3.5.1/exchangeconnector-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-exchangeconnector.jar"; fi
# artifact com.attivio.platform.modules:gwt-commons
if [ -f "${ATTIVIO_HOME}/lib/aie-module-gwt-commons.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/gwt-commons/3.5.1/gwt-commons-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-gwt-commons.jar"; fi
# artifact com.attivio.platform.modules:indexbackup
if [ -f "${ATTIVIO_HOME}/lib/aie-module-indexbackup.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/indexbackup/3.5.1/indexbackup-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-indexbackup.jar"; fi
# artifact com.attivio.platform.modules:jdbcutils
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jdbcutils.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jdbcutils/3.5.1/jdbcutils-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jdbcutils.jar"; fi
# artifact com.attivio.platform.modules:jmeter
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jmeter.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jmeter/3.5.1/jmeter-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jmeter.jar"; fi
# artifact com.attivio.platform.modules:jms
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jms.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jms/3.5.1/jms-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jms.jar"; fi
# artifact com.attivio.platform.modules:jspsupport
if [ -f "${ATTIVIO_HOME}/lib/aie-module-jspsupport.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/jspsupport/3.5.1/jspsupport-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-jspsupport.jar"; fi
# artifact com.attivio.platform.modules:keyphrases
if [ -f "${ATTIVIO_HOME}/lib/aie-module-keyphrases.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/keyphrases/3.5.1/keyphrases-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-keyphrases.jar"; fi
# artifact com.attivio.platform.modules:languagemodel
if [ -f "${ATTIVIO_HOME}/lib/aie-module-languagemodel.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/languagemodel/3.5.1/languagemodel-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-languagemodel.jar"; fi
# artifact com.attivio.platform.modules:memory
if [ -f "${ATTIVIO_HOME}/lib/aie-module-memory.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/memory/3.5.1/memory-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-memory.jar"; fi
# artifact com.attivio.platform.modules:morelikethis
if [ -f "${ATTIVIO_HOME}/lib/aie-module-morelikethis.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/morelikethis/3.5.1/morelikethis-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-morelikethis.jar"; fi
# artifact com.attivio.platform.modules:ontology
if [ -f "${ATTIVIO_HOME}/lib/aie-module-ontology.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/ontology/3.5.1/ontology-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-ontology.jar"; fi
# artifact com.attivio.platform.modules:opensearch
if [ -f "${ATTIVIO_HOME}/lib/aie-module-opensearch.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/opensearch/3.5.1/opensearch-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-opensearch.jar"; fi
# artifact com.attivio.platform.modules:profiler
if [ -f "${ATTIVIO_HOME}/lib/aie-module-profiler.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/profiler/3.5.1/profiler-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-profiler.jar"; fi
# artifact com.attivio.platform.modules:scheduler
if [ -f "${ATTIVIO_HOME}/lib/aie-module-scheduler.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/scheduler/3.5.1/scheduler-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-scheduler.jar"; fi
# artifact com.attivio.platform.modules:sdk
if [ -f "${ATTIVIO_HOME}/lib/aie-module-sdk.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/sdk/3.5.1/sdk-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-sdk.jar"; fi
# artifact com.attivio.platform.modules:security
if [ -f "${ATTIVIO_HOME}/lib/aie-module-security.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/security/3.5.1/security-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-security.jar"; fi
# artifact com.attivio.platform.modules:security-ad
if [ -f "${ATTIVIO_HOME}/lib/aie-module-security-ad.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/security-ad/3.5.1/security-ad-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-security-ad.jar"; fi
# artifact com.attivio.platform.modules:sentiment
if [ -f "${ATTIVIO_HOME}/lib/aie-module-sentiment.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/sentiment/3.5.1/sentiment-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-sentiment.jar"; fi
# artifact com.attivio.platform.modules:simplesearchui
if [ -f "${ATTIVIO_HOME}/lib/aie-module-simplesearchui.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/simplesearchui/3.5.1/simplesearchui-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-simplesearchui.jar"; fi
# artifact com.attivio.platform.modules:siteharvester
if [ -f "${ATTIVIO_HOME}/lib/aie-module-siteharvester.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/siteharvester/3.5.1/siteharvester-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-siteharvester.jar"; fi
# artifact com.attivio.platform.modules:structureextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-structureextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/structureextraction/3.5.1/structureextraction-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-structureextraction.jar"; fi
# artifact com.attivio.platform.modules:textextraction
if [ -f "${ATTIVIO_HOME}/lib/aie-module-textextraction.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/textextraction/3.5.1/textextraction-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-textextraction.jar"; fi
# artifact com.attivio.platform.modules:webservice
if [ -f "${ATTIVIO_HOME}/lib/aie-module-webservice.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/webservice/3.5.1/webservice-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-webservice.jar"; fi
# artifact com.attivio.platform.modules:workflows
if [ -f "${ATTIVIO_HOME}/lib/aie-module-workflows.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflows/3.5.1/workflows-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-workflows.jar"; fi
# artifact com.attivio.platform.modules:workflowvisualizer
if [ -f "${ATTIVIO_HOME}/lib/aie-module-workflowvisualizer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflowvisualizer/3.5.1/workflowvisualizer-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-module-workflowvisualizer.jar"; fi
# artifact com.attivio.platform.modules.workflowvisualizer:workflowvisualizer-parent
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/modules/workflowvisualizer/workflowvisualizer-parent/3.5.1/workflowvisualizer-parent-3.5.1.pom -Dfile=./com/attivio/platform/modules/workflowvisualizer/workflowvisualizer-parent/3.5.1/workflowvisualizer-parent-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform:platform
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/3.5.1/platform-3.5.1.pom -Dfile=./com/attivio/platform/platform/3.5.1/platform-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.platform:base
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/3.5.1/base-3.5.1.pom -Dfile=./com/attivio/platform/platform/base/3.5.1/base-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.base:connector
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-connector.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/connector/3.5.1/connector-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-connector.jar"; fi
# artifact com.attivio.platform.platform.base:tokenizer
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-tokenizer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/tokenizer/3.5.1/tokenizer-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-tokenizer.jar"; fi
# artifact com.attivio.platform.platform.base:transformer
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-base-transformer.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/base/transformer/3.5.1/transformer-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-base-transformer.jar"; fi
# artifact com.attivio.platform.platform:esb
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/3.5.1/esb-3.5.1.pom -Dfile=./com/attivio/platform/platform/esb/3.5.1/esb-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.esb:api
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-api.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/api/3.5.1/api-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-api.jar"; fi
# artifact com.attivio.platform.platform.esb:exposedapi
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-exposedapi.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/exposedapi/3.5.1/exposedapi-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-exposedapi.jar"; fi
# artifact com.attivio.platform.platform.esb:launcher
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-launcher.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/launcher/3.5.1/launcher-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-launcher.jar"; fi
# artifact com.attivio.platform.platform.esb:model
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/model/3.5.1/model-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-model.jar"; fi
# artifact com.attivio.platform.platform.esb:mule
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-mule.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/mule/3.5.1/mule-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-mule.jar"; fi
# artifact com.attivio.platform.platform.esb:zoo
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-esb-zoo.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/esb/zoo/3.5.1/zoo-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-esb-zoo.jar"; fi
# artifact com.attivio.platform.platform:perfmon
mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/3.5.1/perfmon-3.5.1.pom -Dfile=./com/attivio/platform/platform/perfmon/3.5.1/perfmon-3.5.1.pom -Dpackaging=pom
# artifact com.attivio.platform.platform.perfmon:client
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-client.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/client/3.5.1/client-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-client.jar"; fi
# artifact com.attivio.platform.platform.perfmon:model
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-model.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/model/3.5.1/model-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-model.jar"; fi
# artifact com.attivio.platform.platform.perfmon:server
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-perfmon-server.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/perfmon/server/3.5.1/server-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-perfmon-server.jar"; fi
# artifact com.attivio.platform.platform:util
if [ -f "${ATTIVIO_HOME}/lib/aie-platform-util.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/attivio/platform/platform/util/3.5.1/util-3.5.1.pom -Dfile="${ATTIVIO_HOME}/lib/aie-platform-util.jar"; fi
# artifact com.datadirect:aie-module-sqlsdk-jdbc
if [ -f "${ATTIVIO_HOME}/sqlsdk/lib/aie-module-sqlsdk-jdbc-7.0.0.0143-v4.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/datadirect/aie-module-sqlsdk-jdbc/7.2.0.0014-v1/aie-module-sqlsdk-jdbc-7.2.0.0014-v1.pom -Dfile="${ATTIVIO_HOME}/sqlsdk/lib/aie-module-sqlsdk-jdbc-7.0.0.0143-v4.jar"; fi
# artifact com.ibm.icu:icu4j
if [ -f "${ATTIVIO_HOME}/lib/icu4j-3.8.1.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/ibm/icu/icu4j/3.8.1/icu4j-3.8.1.pom -Dfile="${ATTIVIO_HOME}/lib/icu4j-3.8.1.jar"; fi
# artifact com.sun.mail:dsn
if [ -f "${ATTIVIO_HOME}/lib/dsn-1.4.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/sun/mail/dsn/1.4.3/dsn-1.4.3.pom -Dfile="${ATTIVIO_HOME}/lib/dsn-1.4.3.jar"; fi
# artifact com.sun.mail:imap
if [ -f "${ATTIVIO_HOME}/lib/imap-1.4.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/sun/mail/imap/1.4.3/imap-1.4.3.pom -Dfile="${ATTIVIO_HOME}/lib/imap-1.4.3.jar"; fi
# artifact com.sun.mail:mailapi
if [ -f "${ATTIVIO_HOME}/lib/mailapi-1.4.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/sun/mail/mailapi/1.4.3/mailapi-1.4.3.pom -Dfile="${ATTIVIO_HOME}/lib/mailapi-1.4.3.jar"; fi
# artifact com.sun.mail:pop3
if [ -f "${ATTIVIO_HOME}/lib/pop3-1.4.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/sun/mail/pop3/1.4.3/pop3-1.4.3.pom -Dfile="${ATTIVIO_HOME}/lib/pop3-1.4.3.jar"; fi
# artifact com.sun.mail:smtp
if [ -f "${ATTIVIO_HOME}/lib/smtp-1.4.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./com/sun/mail/smtp/1.4.3/smtp-1.4.3.pom -Dfile="${ATTIVIO_HOME}/lib/smtp-1.4.3.jar"; fi
# artifact de.intrasys.cwt:iscwt
if [ -f "${ATTIVIO_HOME}/lib/iscwt-5.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./de/intrasys/cwt/iscwt/5.2/iscwt-5.2.pom -Dfile="${ATTIVIO_HOME}/lib/iscwt-5.2.jar"; fi
# artifact de.intrasys.tools:isrt
if [ -f "${ATTIVIO_HOME}/lib/isrt-4.7.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./de/intrasys/tools/isrt/4.7/isrt-4.7.pom -Dfile="${ATTIVIO_HOME}/lib/isrt-4.7.jar"; fi
# artifact javax.management:jmxremote_optional
if [ -f "${ATTIVIO_HOME}/lib/jmxremote_optional-1.0.1_04.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./javax/management/jmxremote_optional/1.0.1_04/jmxremote_optional-1.0.1_04.pom -Dfile="${ATTIVIO_HOME}/lib/jmxremote_optional-1.0.1_04.jar"; fi
# artifact opencsv:opencsv
if [ -f "${ATTIVIO_HOME}/lib/opencsv-1.8.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./opencsv/opencsv/1.8/opencsv-1.8.pom -Dfile="${ATTIVIO_HOME}/lib/opencsv-1.8.jar"; fi
# artifact org.apache.poi:poi-contrib
if [ -f "${ATTIVIO_HOME}/lib/poi-contrib-3.2-NIObackport-20110105.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/apache/poi/poi-contrib/3.2-NIObackport-20110105/poi-contrib-3.2-NIObackport-20110105.pom -Dfile="${ATTIVIO_HOME}/lib/poi-contrib-3.2-NIObackport-20110105.jar"; fi
# artifact org.apache.poi:poi-ooxml
if [ -f "${ATTIVIO_HOME}/lib/poi-ooxml-3.7-20100617171931.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/apache/poi/poi-ooxml/3.7-20100617171931/poi-ooxml-3.7-20100617171931.pom -Dfile="${ATTIVIO_HOME}/lib/poi-ooxml-3.7-20100617171931.jar"; fi
# artifact org.apache.poi:poi-ooxml-schemas
if [ -f "${ATTIVIO_HOME}/lib/poi-ooxml-schemas-3.7-20100617171931.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/apache/poi/poi-ooxml-schemas/3.7-20100617171931/poi-ooxml-schemas-3.7-20100617171931.pom -Dfile="${ATTIVIO_HOME}/lib/poi-ooxml-schemas-3.7-20100617171931.jar"; fi
# artifact org.hyperic.sigar:sigar
if [ -f "${ATTIVIO_HOME}/lib/sigar-1.6.4-attiviopatch2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/hyperic/sigar/sigar/1.6.4-attiviopatch2/sigar-1.6.4-attiviopatch2.pom -Dfile="${ATTIVIO_HOME}/lib/sigar-1.6.4-attiviopatch2.jar"; fi
# artifact org.jpedal:jbig2
if [ -f "${ATTIVIO_HOME}/lib/jbig2-1.5.0_12-b04.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/jpedal/jbig2/1.5.0_12-b04/jbig2-1.5.0_12-b04.pom -Dfile="${ATTIVIO_HOME}/lib/jbig2-1.5.0_12-b04.jar"; fi
# artifact org.moxieapps.gwt:highcharts
if [ -f "${ATTIVIO_HOME}/lib/highcharts-1.4.0.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./org/moxieapps/gwt/highcharts/1.4.0/highcharts-1.4.0.pom -Dfile="${ATTIVIO_HOME}/lib/highcharts-1.4.0.jar"; fi
# artifact rtf2fo:rtf2fo
if [ -f "${ATTIVIO_HOME}/lib/rtf2fo-3.4.4d.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./rtf2fo/rtf2fo/3.4.4d/rtf2fo-3.4.4d.pom -Dfile="${ATTIVIO_HOME}/lib/rtf2fo-3.4.4d.jar"; fi
# artifact trove:trove
if [ -f "${ATTIVIO_HOME}/lib/trove-2.0.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./trove/trove/2.0.2/trove-2.0.2.pom -Dfile="${ATTIVIO_HOME}/lib/trove-2.0.2.jar"; fi
# artifact velocity:velocity
if [ -f "${ATTIVIO_HOME}/lib/velocity-1.6.2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./velocity/velocity/1.6.2/velocity-1.6.2.pom -Dfile="${ATTIVIO_HOME}/lib/velocity-1.6.2.jar"; fi
# artifact velocity:velocity-tools
if [ -f "${ATTIVIO_HOME}/lib/velocity-tools-1.4.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -DpomFile=./velocity/velocity-tools/1.4/velocity-tools-1.4.pom -Dfile="${ATTIVIO_HOME}/lib/velocity-tools-1.4.jar"; fi
