#! /bin/sh
#
# install AIE dependencies not in maven central
# alternatively, add the following repositories to your pom:
# Ontotext Aduna Maven Repository http://maven.ontotext.com/content/repositories/aduna/
# Aperture Maven Repository http://aperture.sourceforge.net/maven/
# Semweb4j.org maven repo http://semweb4j.org/repo/
#
# usage
# export ATTIVIO_HOME=/opt/attivio/aie_4.2.0
# aie-mvn-deploy-nonmc.bat "-Durl=file://${home}/.m2/repository" "-Drepository=localrepo"

if [ -f "${ATTIVIO_HOME}/lib/aperture-tools-demork-1.0.0.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/aperture-tools-demork-1.0.0.jar" -DartifactId=aperture-tools-demork -DgroupId=org.semanticdesktop.nepomuk -Dversion=1.0.0; fi
if [ -f "${ATTIVIO_HOME}/lib/rdf2go.api-4.7.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/rdf2go.api-4.7.3.jar" -DartifactId=rdf2go.api -DgroupId=org.semweb4j -Dversion=4.7.3; fi
if [ -f "${ATTIVIO_HOME}/lib/rdf2go.api-4.8.3.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/rdf2go.api-4.8.3.jar" -DartifactId=rdf2go.api -DgroupId=org.semweb4j -Dversion=4.8.3; fi
if [ -f "${ATTIVIO_HOME}/lib/bcmail-jdk14-1.43.bundle2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bcmail-jdk14-1.43.bundle2.jar" -DartifactId=bcmail-jdk14 -DgroupId=org.bouncycastle -Dversion=1.43.bundle2; fi
if [ -f "${ATTIVIO_HOME}/lib/bcprov-jdk14-1.43.bundle2.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bcprov-jdk14-1.43.bundle2.jar" -DartifactId=bcprov-jdk14 -DgroupId=org.bouncycastle -Dversion=1.43.bundle2; fi
if [ -f "${ATTIVIO_HOME}/lib/htmlparser-1.6.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/htmlparser-1.6.bundle.jar" -DartifactId=htmlparser -DgroupId=org.htmlparser -Dversion=1.6.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/juniversalchardet-1.0.3.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/juniversalchardet-1.0.3.bundle.jar" -DartifactId=juniversalchardet -DgroupId=net.sourceforge.juniversalchardet -Dversion=1.0.3.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/ical4j-1.0-rc2-byantheque.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/ical4j-1.0-rc2-byantheque.bundle.jar" -DartifactId=ical4j -DgroupId=net.fortuna.ical4j -Dversion=1.0-rc2-byantheque.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/ical4j-vcard-0.9.3.ant20100406.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/ical4j-vcard-0.9.3.ant20100406.jar" -DartifactId=ical4j-vcard -DgroupId=net.fortuna.ical4j -Dversion=0.9.3.ant20100406; fi
if [ -f "${ATTIVIO_HOME}/lib/mstor-0.9.13-SNAPSHOT-aperture13.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/mstor-0.9.13-SNAPSHOT-aperture13.jar" -DartifactId=mstor -DgroupId=net.fortuna.mstor -Dversion=0.9.13-SNAPSHOT-aperture13; fi
if [ -f "${ATTIVIO_HOME}/lib/metadata-extractor-2.4.0-beta1.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/metadata-extractor-2.4.0-beta1.bundle.jar" -DartifactId=metadata-extractor -DgroupId=com.drewnoakes -Dversion=2.4.0-beta1.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/jaudiotagger-1.0.8.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/jaudiotagger-1.0.8.bundle.jar" -DartifactId=jaudiotagger -DgroupId=org.jaudiotagger -Dversion=1.0.8.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/jutf7-0.9.0.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/jutf7-0.9.0.bundle.jar" -DartifactId=jutf7 -DgroupId=com.beetstra.jutf7 -Dversion=0.9.0.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/jacob-1.14.3.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/jacob-1.14.3.bundle.jar" -DartifactId=jacob -DgroupId=net.sf.jacob-project -Dversion=1.14.3.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/flickrapi-1.2.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flickrapi-1.2.bundle.jar" -DartifactId=flickrapi -DgroupId=com.aetrion.flickr -Dversion=1.2.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-rest-client.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-rest-client.bundle.jar" -DartifactId=bibsonomy-rest-client -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-rest-common.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-rest-common.bundle.jar" -DartifactId=bibsonomy-rest-common -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-model.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-model.bundle.jar" -DartifactId=bibsonomy-model -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-common.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-common.bundle.jar" -DartifactId=bibsonomy-common -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-rest-client-2.0.4.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-rest-client-2.0.4.bundle.jar" -DartifactId=bibsonomy-rest-client -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-rest-common-2.0.4.bundle.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-rest-common-2.0.4.bundle.jar" -DartifactId=bibsonomy-rest-common -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-model.bundle-2.0.4.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-model-2.0.4.bundle.jar" -DartifactId=bibsonomy-model -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/bibsonomy-common.bundle-2.0.4.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/bibsonomy-common-2.0.4.bundle.jar" -DartifactId=bibsonomy-common -DgroupId=org.bibsonomy -Dversion=2.0.4-SNAPSHOT.bundle; fi
if [ -f "${ATTIVIO_HOME}/lib/jcifs-1.3.14.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/jcifs-1.3.14.jar" -DartifactId=jcifs -DgroupId=org.samba.jcifs -Dversion=1.3.14; fi
if [ -f "${ATTIVIO_HOME}/lib/xercesImpl-2.9.1.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/xercesImpl-2.9.1.jar" -DartifactId=xercesImpl -DgroupId=apache-xerces -Dversion=2.9.1; fi
if [ -f "${ATTIVIO_HOME}/lib/flex-messaging-common-3.2.0.3978.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flex-messaging-common-3.2.0.3978.jar" -DartifactId=flex-messaging-common -DgroupId=com.adobe -Dversion=3.2.0.3978; fi
if [ -f "${ATTIVIO_HOME}/lib/flex-messaging-core-3.2.0.3978.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flex-messaging-core-3.2.0.3978.jar" -DartifactId=flex-messaging-core -DgroupId=com.adobe -Dversion=3.2.0.3978; fi
if [ -f "${ATTIVIO_HOME}/lib/flex-messaging-opt-3.2.0.3978.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flex-messaging-opt-3.2.0.3978.jar" -DartifactId=flex-messaging-opt -DgroupId=com.adobe -Dversion=3.2.0.3978; fi
if [ -f "${ATTIVIO_HOME}/lib/flex-messaging-proxy-3.2.0.3978.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flex-messaging-proxy-3.2.0.3978.jar" -DartifactId=flex-messaging-proxy -DgroupId=com.adobe -Dversion=3.2.0.3978; fi
if [ -f "${ATTIVIO_HOME}/lib/flex-messaging-remoting-3.2.0.3978.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/flex-messaging-remoting-3.2.0.3978.jar" -DartifactId=flex-messaging-remoting -DgroupId=com.adobe -Dversion=3.2.0.3978; fi
if [ -f "${ATTIVIO_HOME}/lib/backport-util-concurrent-Java60-3.1.jar" ]; then mvn deploy:deploy-file $1 $2 $3 $4 $5 $6 -Dfile="${ATTIVIO_HOME}/lib/backport-util-concurrent-Java60-3.1.jar" -DartifactId=backport-util-concurrent-Java60 -DgroupId=backport-util-concurrent -Dversion=3.1; fi

